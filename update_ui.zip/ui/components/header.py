"""
ui/components/header.py
"""

import streamlit as st
from state import clear_error, go_to_list


def render_header() -> None:

    if st.session_state.view == "list":
        st.markdown("""
        <div class="cs-header-fixed">
            <div class="cs-header-title">💳 Credit Card Summarizer</div>
            <div class="cs-header-sub">conversations</div>
        </div>
        """, unsafe_allow_html=True)

    else:
        # Fixed title bar (pure HTML, always visible)
        st.markdown("""
        <div class="cs-header-fixed">
            <div class="cs-header-title">💳 Credit Card Summarizer</div>
        </div>
        """, unsafe_allow_html=True)

        # Wrap the columns in a div with a unique class so CSS can
        # target exactly this block and fix it to the top
        st.markdown('<div class="cs-chat-nav">', unsafe_allow_html=True)
        left, _mid, right = st.columns([2, 6, 2])
        with left:
            if st.button("← Back", key="header_back_btn"):
                go_to_list()
                st.rerun()
        with right:
            if st.button("🗑 Delete", key="header_delete_btn"):
                st.session_state.confirm_delete = True
                st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)


def render_error_banner() -> None:
    if st.session_state.error:
        st.markdown(
            f'<div class="cs-error">{st.session_state.error}</div>',
            unsafe_allow_html=True,
        )
        if st.button("Dismiss", key="dismiss_error"):
            clear_error()
            st.rerun()